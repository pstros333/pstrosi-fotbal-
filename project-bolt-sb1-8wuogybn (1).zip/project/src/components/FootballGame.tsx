import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';

interface GameState {
  score: { home: number; away: number };
  time: number;
  phase: 'menu' | 'playing' | 'goal' | 'gameover';
  message: string;
}

const FIELD_W = 60;
const FIELD_H = 40;
const GOAL_W = 8;
const GOAL_H = 3;
const BALL_RADIUS = 0.5;
const PLAYER_RADIUS = 0.6;
const PLAYER_HEIGHT = 1.8;

export default function FootballGame() {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    ball: THREE.Mesh;
    playerMesh: THREE.Group;
    aiMesh: THREE.Group;
    ballVel: THREE.Vector3;
    playerPos: THREE.Vector3;
    aiPos: THREE.Vector3;
    keys: Set<string>;
    animId: number;
    time: number;
    goalCooldown: number;
  } | null>(null);

  const [gameState, setGameState] = useState<GameState>({
    score: { home: 0, away: 0 },
    time: 120,
    phase: 'menu',
    message: '',
  });
  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  const scoreRef = useRef({ home: 0, away: 0 });
  const timeRef = useRef(120);

  const createField = (scene: THREE.Scene) => {
    // Ground
    const groundGeo = new THREE.PlaneGeometry(FIELD_W, FIELD_H);
    const groundMat = new THREE.MeshLambertMaterial({ color: 0x2d8a3e });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Stripe pattern
    for (let i = 0; i < 6; i++) {
      const stripeGeo = new THREE.PlaneGeometry(FIELD_W / 6, FIELD_H);
      const stripeMat = new THREE.MeshLambertMaterial({
        color: i % 2 === 0 ? 0x2d8a3e : 0x33a047,
        transparent: true,
        opacity: 0.6,
      });
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(-FIELD_W / 2 + FIELD_W / 12 + (i * FIELD_W) / 6, 0.01, 0);
      scene.add(stripe);
    }

    // Line material
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const addLine = (w: number, h: number, x: number, z: number) => {
      const geo = new THREE.PlaneGeometry(w, h);
      const mesh = new THREE.Mesh(geo, lineMat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.set(x, 0.02, z);
      scene.add(mesh);
    };

    // Border lines
    addLine(FIELD_W, 0.15, 0, -FIELD_H / 2);
    addLine(FIELD_W, 0.15, 0, FIELD_H / 2);
    addLine(0.15, FIELD_H, -FIELD_W / 2, 0);
    addLine(0.15, FIELD_H, FIELD_W / 2, 0);
    // Center line
    addLine(0.15, FIELD_H, 0, 0);

    // Center circle
    const circlePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 64; i++) {
      const a = (i / 64) * Math.PI * 2;
      circlePoints.push(new THREE.Vector3(Math.cos(a) * 5, 0.02, Math.sin(a) * 5));
    }
    const circleCurve = new THREE.CatmullRomCurve3(circlePoints);
    const circleGeo = new THREE.TubeGeometry(circleCurve, 64, 0.07, 4, false);
    scene.add(new THREE.Mesh(circleGeo, lineMat));

    // Goals
    const createGoal = (x: number) => {
      const postMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
      const postGeo = new THREE.CylinderGeometry(0.1, 0.1, GOAL_H, 8);
      // Left post
      const lp = new THREE.Mesh(postGeo, postMat);
      lp.position.set(x, GOAL_H / 2, -GOAL_W / 2);
      lp.castShadow = true;
      scene.add(lp);
      // Right post
      const rp = new THREE.Mesh(postGeo, postMat);
      rp.position.set(x, GOAL_H / 2, GOAL_W / 2);
      rp.castShadow = true;
      scene.add(rp);
      // Crossbar
      const cbGeo = new THREE.CylinderGeometry(0.1, 0.1, GOAL_W, 8);
      const cb = new THREE.Mesh(cbGeo, postMat);
      cb.rotation.x = Math.PI / 2;
      cb.position.set(x, GOAL_H, 0);
      cb.castShadow = true;
      scene.add(cb);
      // Net
      const netMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        wireframe: true,
        transparent: true,
        opacity: 0.3,
      });
      const netDepth = x > 0 ? 3 : -3;
      const netGeo = new THREE.BoxGeometry(Math.abs(netDepth), GOAL_H, GOAL_W);
      const net = new THREE.Mesh(netGeo, netMat);
      net.position.set(x + netDepth / 2, GOAL_H / 2, 0);
      scene.add(net);
    };

    createGoal(-FIELD_W / 2);
    createGoal(FIELD_W / 2);
  };

  const createPlayer = (color: number): THREE.Group => {
    const group = new THREE.Group();
    const bodyMat = new THREE.MeshLambertMaterial({ color });
    const skinMat = new THREE.MeshLambertMaterial({ color: 0xffcc99 });

    // Body
    const bodyGeo = new THREE.CylinderGeometry(PLAYER_RADIUS * 0.5, PLAYER_RADIUS * 0.6, 1.0, 8);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 0.9;
    body.castShadow = true;
    group.add(body);

    // Head
    const headGeo = new THREE.SphereGeometry(0.3, 8, 8);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 1.7;
    head.castShadow = true;
    group.add(head);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.15, 0.12, 0.8, 8);
    const legMat = new THREE.MeshLambertMaterial({ color: 0x222255 });
    const legL = new THREE.Mesh(legGeo, legMat);
    legL.position.set(-0.22, 0.4, 0);
    legL.castShadow = true;
    group.add(legL);
    const legR = new THREE.Mesh(legGeo, legMat);
    legR.position.set(0.22, 0.4, 0);
    legR.castShadow = true;
    group.add(legR);

    return group;
  };

  const createBall = (): THREE.Mesh => {
    const geo = new THREE.SphereGeometry(BALL_RADIUS, 16, 16);
    const mat = new THREE.MeshLambertMaterial({ color: 0xf0f0f0 });
    const ball = new THREE.Mesh(geo, mat);
    ball.castShadow = true;

    // Pentagon patches
    const patchMat = new THREE.MeshLambertMaterial({ color: 0x111111 });
    const patchPositions = [
      [0, 1, 0], [0, -1, 0], [1, 0.3, 0], [-1, 0.3, 0],
      [0, 0.3, 1], [0, 0.3, -1],
    ];
    patchPositions.forEach(([x, y, z]) => {
      const pGeo = new THREE.CircleGeometry(0.18, 5);
      const patch = new THREE.Mesh(pGeo, patchMat);
      patch.position.set(x * BALL_RADIUS * 0.9, y * BALL_RADIUS * 0.9, z * BALL_RADIUS * 0.9);
      patch.lookAt(x * 2, y * 2, z * 2);
      ball.add(patch);
    });

    return ball;
  };

  const setupScene = useCallback(() => {
    if (!mountRef.current) return;

    const W = mountRef.current.clientWidth;
    const H = mountRef.current.clientHeight;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(W, H);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor(0x87ceeb);
    mountRef.current.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x87ceeb, 40, 100);

    // Lighting
    const ambient = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xfff5e0, 1.2);
    sun.position.set(20, 40, 10);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 2048;
    sun.shadow.mapSize.height = 2048;
    sun.shadow.camera.near = 0.5;
    sun.shadow.camera.far = 150;
    sun.shadow.camera.left = -50;
    sun.shadow.camera.right = 50;
    sun.shadow.camera.top = 50;
    sun.shadow.camera.bottom = -50;
    scene.add(sun);

    // Sky backdrop
    const skyGeo = new THREE.SphereGeometry(80, 16, 16);
    const skyMat = new THREE.MeshBasicMaterial({ color: 0x87ceeb, side: THREE.BackSide });
    scene.add(new THREE.Mesh(skyGeo, skyMat));

    // Stadium stands (simple)
    const standMat = new THREE.MeshLambertMaterial({ color: 0xdddddd });
    const stands = [
      { w: FIELD_W + 10, h: 6, d: 3, x: 0, z: FIELD_H / 2 + 4 },
      { w: FIELD_W + 10, h: 6, d: 3, x: 0, z: -(FIELD_H / 2 + 4) },
    ];
    stands.forEach(({ w, h, d, x, z }) => {
      const geo = new THREE.BoxGeometry(w, h, d);
      const mesh = new THREE.Mesh(geo, standMat);
      mesh.position.set(x, h / 2, z);
      mesh.receiveShadow = true;
      scene.add(mesh);
    });

    createField(scene);

    const ball = createBall();
    ball.position.set(0, BALL_RADIUS, 0);
    scene.add(ball);

    const playerMesh = createPlayer(0x1a6ab1);
    playerMesh.position.set(-5, 0, 0);
    scene.add(playerMesh);

    const aiMesh = createPlayer(0xc0392b);
    aiMesh.position.set(5, 0, 0);
    scene.add(aiMesh);

    const camera = new THREE.PerspectiveCamera(60, W / H, 0.1, 200);
    camera.position.set(0, 25, 30);
    camera.lookAt(0, 0, 0);

    const keys = new Set<string>();
    const onKey = (e: KeyboardEvent, down: boolean) => {
      down ? keys.add(e.code) : keys.delete(e.code);
    };
    window.addEventListener('keydown', (e) => onKey(e, true));
    window.addEventListener('keyup', (e) => onKey(e, false));

    sceneRef.current = {
      renderer, scene, camera, ball,
      playerMesh, aiMesh,
      ballVel: new THREE.Vector3(),
      playerPos: new THREE.Vector3(-5, 0, 0),
      aiPos: new THREE.Vector3(5, 0, 0),
      keys,
      animId: 0,
      time: 120,
      goalCooldown: 0,
    };

    const handleResize = () => {
      if (!mountRef.current || !sceneRef.current) return;
      const { renderer, camera } = sceneRef.current;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', (e) => onKey(e, true));
      window.removeEventListener('keyup', (e) => onKey(e, false));
    };
  }, []);

  const resetBall = () => {
    if (!sceneRef.current) return;
    const s = sceneRef.current;
    s.ball.position.set(0, BALL_RADIUS, 0);
    s.ballVel.set(0, 0, 0);
    s.playerPos.set(-5, 0, 0);
    s.playerMesh.position.set(-5, 0, 0);
    s.aiPos.set(5, 0, 0);
    s.aiMesh.position.set(5, 0, 0);
  };

  const startGame = () => {
    if (!sceneRef.current) return;
    scoreRef.current = { home: 0, away: 0 };
    timeRef.current = 120;
    sceneRef.current.time = 120;
    sceneRef.current.goalCooldown = 0;
    resetBall();
    setGameState({ score: { home: 0, away: 0 }, time: 120, phase: 'playing', message: '' });
    startLoop();
  };

  const startLoop = () => {
    if (!sceneRef.current) return;
    const s = sceneRef.current;
    let lastTime = performance.now();
    let elapsed = 0;

    const tick = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      if (gameStateRef.current.phase !== 'playing') {
        s.renderer.render(s.scene, s.camera);
        s.animId = requestAnimationFrame(tick);
        return;
      }

      // Timer
      elapsed += dt;
      if (elapsed >= 1) {
        elapsed = 0;
        timeRef.current = Math.max(0, timeRef.current - 1);
        if (timeRef.current === 0) {
          setGameState(prev => ({ ...prev, phase: 'gameover', time: 0 }));
        }
        setGameState(prev => ({ ...prev, time: timeRef.current }));
      }

      if (s.goalCooldown > 0) {
        s.goalCooldown -= dt;
        if (s.goalCooldown <= 0) {
          resetBall();
          setGameState(prev => ({ ...prev, phase: 'playing', message: '' }));
        }
        s.renderer.render(s.scene, s.camera);
        s.animId = requestAnimationFrame(tick);
        return;
      }

      // Player movement
      const speed = 8;
      const dir = new THREE.Vector3();
      if (s.keys.has('ArrowLeft') || s.keys.has('KeyA')) dir.z += 1;
      if (s.keys.has('ArrowRight') || s.keys.has('KeyD')) dir.z -= 1;
      if (s.keys.has('ArrowUp') || s.keys.has('KeyW')) dir.x -= 1;
      if (s.keys.has('ArrowDown') || s.keys.has('KeyS')) dir.x += 1;

      if (dir.length() > 0) dir.normalize();
      s.playerPos.x += dir.x * speed * dt;
      s.playerPos.z += dir.z * speed * dt;

      // Player bounds
      s.playerPos.x = Math.max(-FIELD_W / 2 + 1, Math.min(FIELD_W / 2 - 1, s.playerPos.x));
      s.playerPos.z = Math.max(-FIELD_H / 2 + 1, Math.min(FIELD_H / 2 - 1, s.playerPos.z));
      s.playerMesh.position.set(s.playerPos.x, 0, s.playerPos.z);

      // Rotate player towards movement
      if (dir.length() > 0.1) {
        const angle = Math.atan2(dir.z, dir.x);
        s.playerMesh.rotation.y = -angle;
      }

      // AI movement
      const toBall = new THREE.Vector3().subVectors(s.ball.position, s.aiPos);
      toBall.y = 0;
      const aiSpeed = 5.5 + Math.random() * 0.5;
      if (toBall.length() > 0.1) {
        toBall.normalize();
        s.aiPos.x += toBall.x * aiSpeed * dt;
        s.aiPos.z += toBall.z * aiSpeed * dt;
      }
      s.aiPos.x = Math.max(-FIELD_W / 2 + 1, Math.min(FIELD_W / 2 - 1, s.aiPos.x));
      s.aiPos.z = Math.max(-FIELD_H / 2 + 1, Math.min(FIELD_H / 2 - 1, s.aiPos.z));
      s.aiMesh.position.set(s.aiPos.x, 0, s.aiPos.z);

      const aiAngle = Math.atan2(toBall.z, toBall.x);
      s.aiMesh.rotation.y = -aiAngle;

      // Ball physics
      s.ball.position.addScaledVector(s.ballVel, dt);
      s.ballVel.x *= 0.97;
      s.ballVel.z *= 0.97;
      s.ball.position.y = BALL_RADIUS; // keep on ground

      // Rotate ball based on movement
      s.ball.rotation.z -= s.ballVel.x * dt * 2;
      s.ball.rotation.x += s.ballVel.z * dt * 2;

      // Ball wall bounce
      if (s.ball.position.x < -FIELD_W / 2 + BALL_RADIUS) {
        s.ball.position.x = -FIELD_W / 2 + BALL_RADIUS;
        s.ballVel.x = Math.abs(s.ballVel.x) * 0.6;
      }
      if (s.ball.position.x > FIELD_W / 2 - BALL_RADIUS) {
        s.ball.position.x = FIELD_W / 2 - BALL_RADIUS;
        s.ballVel.x = -Math.abs(s.ballVel.x) * 0.6;
      }
      if (s.ball.position.z < -FIELD_H / 2 + BALL_RADIUS) {
        s.ball.position.z = -FIELD_H / 2 + BALL_RADIUS;
        s.ballVel.z = Math.abs(s.ballVel.z) * 0.6;
      }
      if (s.ball.position.z > FIELD_H / 2 - BALL_RADIUS) {
        s.ball.position.z = FIELD_H / 2 - BALL_RADIUS;
        s.ballVel.z = -Math.abs(s.ballVel.z) * 0.6;
      }

      // Player-ball collision
      const collide = (pos: THREE.Vector3, kickDir: THREE.Vector3) => {
        const diff = new THREE.Vector3(s.ball.position.x - pos.x, 0, s.ball.position.z - pos.z);
        const dist = diff.length();
        const minDist = PLAYER_RADIUS + BALL_RADIUS;
        if (dist < minDist && dist > 0.01) {
          diff.normalize();
          s.ball.position.x = pos.x + diff.x * minDist;
          s.ball.position.z = pos.z + diff.z * minDist;
          const speed = Math.max(8, kickDir.length() * 12);
          s.ballVel.set(diff.x * speed, 0, diff.z * speed);
        }
      };

      collide(s.playerPos, dir);
      const aiKickDir = new THREE.Vector3(-1, 0, (Math.random() - 0.5) * 0.5).normalize().multiplyScalar(6);
      collide(s.aiPos, aiKickDir);

      // Goal detection
      const bx = s.ball.position.x;
      const bz = s.ball.position.z;
      const inGoalZ = Math.abs(bz) < GOAL_W / 2;

      if (bx < -FIELD_W / 2 + BALL_RADIUS + 0.3 && inGoalZ) {
        // Away scores (AI scores in home goal)
        scoreRef.current = { ...scoreRef.current, away: scoreRef.current.away + 1 };
        setGameState(prev => ({
          ...prev,
          score: { ...scoreRef.current },
          phase: 'goal',
          message: 'GOL! Supe! +1 pre soka',
        }));
        s.goalCooldown = 2.5;
      } else if (bx > FIELD_W / 2 - BALL_RADIUS - 0.3 && inGoalZ) {
        // Home scores
        scoreRef.current = { ...scoreRef.current, home: scoreRef.current.home + 1 };
        setGameState(prev => ({
          ...prev,
          score: { ...scoreRef.current },
          phase: 'goal',
          message: 'GOL! Skvelý strelec!',
        }));
        s.goalCooldown = 2.5;
      }

      // Camera follow player loosely
      const targetCamX = s.playerPos.x * 0.15;
      const targetCamZ = s.playerPos.z * 0.1 + 30;
      s.camera.position.x += (targetCamX - s.camera.position.x) * 0.04;
      s.camera.position.z += (targetCamZ - s.camera.position.z) * 0.04;
      s.camera.lookAt(s.ball.position.x * 0.3, 0, s.ball.position.z * 0.1);

      s.renderer.render(s.scene, s.camera);
      s.animId = requestAnimationFrame(tick);
    };

    s.animId = requestAnimationFrame(tick);
  };

  useEffect(() => {
    const cleanup = setupScene();
    return () => {
      cleanup?.();
      if (sceneRef.current) {
        cancelAnimationFrame(sceneRef.current.animId);
        sceneRef.current.renderer.dispose();
        if (mountRef.current && sceneRef.current.renderer.domElement.parentNode === mountRef.current) {
          mountRef.current.removeChild(sceneRef.current.renderer.domElement);
        }
      }
    };
  }, [setupScene]);

  // Render initial scene on mount (before game starts)
  useEffect(() => {
    if (!sceneRef.current) return;
    const s = sceneRef.current;
    const renderOnce = () => {
      s.renderer.render(s.scene, s.camera);
    };
    renderOnce();
  });

  const formatTime = (t: number) => {
    const m = Math.floor(t / 60);
    const s = t % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="relative w-full h-screen bg-gray-900 overflow-hidden">
      {/* 3D Canvas */}
      <div ref={mountRef} className="w-full h-full" />

      {/* HUD */}
      {gameState.phase === 'playing' || gameState.phase === 'goal' ? (
        <div className="absolute top-0 left-0 right-0 flex justify-between items-start p-4 pointer-events-none">
          {/* Score */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl px-6 py-3 text-white font-bold text-2xl tracking-wider">
            <span className="text-blue-400">{gameState.score.home}</span>
            <span className="mx-3 text-gray-400">:</span>
            <span className="text-red-400">{gameState.score.away}</span>
          </div>

          {/* Timer */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl px-6 py-3 text-white font-mono text-2xl font-bold">
            {formatTime(gameState.time)}
          </div>

          {/* Teams */}
          <div className="bg-black/60 backdrop-blur-sm rounded-xl px-4 py-2 text-sm text-gray-300">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <span>TY</span>
              <span className="mx-2 text-gray-500">vs</span>
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span>AI</span>
            </div>
          </div>
        </div>
      ) : null}

      {/* Goal message */}
      {gameState.phase === 'goal' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-yellow-400/90 text-gray-900 text-4xl font-black px-10 py-6 rounded-2xl shadow-2xl animate-pulse tracking-wide">
            {gameState.message}
          </div>
        </div>
      )}

      {/* Menu overlay */}
      {gameState.phase === 'menu' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="text-center">
            <div className="text-6xl font-black text-white mb-2 tracking-tight">
              FUTBAL <span className="text-green-400">3D</span>
            </div>
            <div className="text-gray-400 text-lg mb-10">Zmeraj sily s AI súperom</div>

            <div className="bg-white/10 rounded-2xl p-6 mb-8 text-left text-gray-200 text-sm space-y-2 max-w-xs mx-auto">
              <div className="text-white font-bold mb-3 text-base">Ovládanie</div>
              <div className="flex gap-3 items-center">
                <kbd className="bg-gray-700 px-2 py-1 rounded text-xs font-mono">W A S D</kbd>
                <span>alebo</span>
                <kbd className="bg-gray-700 px-2 py-1 rounded text-xs font-mono">Šípky</kbd>
              </div>
              <div className="text-gray-400 text-xs mt-1">Pohyb hráča — dotknúť sa lopty = kop</div>
            </div>

            <button
              onClick={startGame}
              className="bg-green-500 hover:bg-green-400 text-white font-bold text-xl px-12 py-4 rounded-2xl transition-all duration-200 hover:scale-105 active:scale-95 shadow-lg shadow-green-500/30"
            >
              Hrať
            </button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameState.phase === 'gameover' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="text-center">
            <div className="text-4xl font-black text-white mb-2">Koniec zápasu</div>
            <div className="text-7xl font-black my-6">
              <span className="text-blue-400">{gameState.score.home}</span>
              <span className="text-gray-500 mx-4">:</span>
              <span className="text-red-400">{gameState.score.away}</span>
            </div>
            <div className="text-xl text-gray-300 mb-8">
              {gameState.score.home > gameState.score.away
                ? 'Vyhral si! Gratulujeme!'
                : gameState.score.home < gameState.score.away
                ? 'Prehral si. Skús znovu!'
                : 'Remíza!'}
            </div>
            <button
              onClick={startGame}
              className="bg-green-500 hover:bg-green-400 text-white font-bold text-xl px-12 py-4 rounded-2xl transition-all duration-200 hover:scale-105 active:scale-95 shadow-lg shadow-green-500/30"
            >
              Hrať znovu
            </button>
          </div>
        </div>
      )}

      {/* Controls hint in-game */}
      {gameState.phase === 'playing' && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/40 backdrop-blur-sm rounded-lg px-4 py-2 text-gray-400 text-xs pointer-events-none">
          W/A/S/D alebo Šípky — pohyb
        </div>
      )}
    </div>
  );
}
