import FootballGame from './components/FootballGame';

function App() {
  return <FootballGame />;
}

export default App;
